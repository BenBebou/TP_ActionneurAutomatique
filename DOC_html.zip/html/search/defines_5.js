var searchData=
[
  ['use_5fhal_5fadc_5fregister_5fcallbacks_0',['USE_HAL_ADC_REGISTER_CALLBACKS',['../stm32g4xx__hal__conf_8h.html#acc33abd5393affd16cc4a1397839dfe4',1,'stm32g4xx_hal_conf.h']]],
  ['use_5fspi_5fcrc_1',['USE_SPI_CRC',['../stm32g4xx__hal__conf_8h.html#a4c6fab687afc7ba4469b1b2d34472358',1,'stm32g4xx_hal_conf.h']]]
];
