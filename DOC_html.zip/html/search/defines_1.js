var searchData=
[
  ['external_5fclock_5fvalue_0',['EXTERNAL_CLOCK_VALUE',['../stm32g4xx__hal__conf_8h.html#a8c47c935e91e70569098b41718558648',1,'stm32g4xx_hal_conf.h']]]
];
