var indexSectionsWithContent =
{
  0: "_abcdefghlmnpstuv",
  1: "fgmstu",
  2: "_abdehmnpstu",
  3: "aehltuv",
  4: "cs"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "defines",
  4: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Macros",
  4: "Modules"
};

